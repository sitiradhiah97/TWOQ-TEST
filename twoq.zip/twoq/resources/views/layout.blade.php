<!DOCTYPE html>
<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    </head>
    <body>
    <div class="container">

        @yield('content')

        </div>
        <div class="card bg-secondary text-white">
            <div class="card-body text-center">Copyright (c) 2024 Example</div>
        </div>
    
   

    </body>



</html>